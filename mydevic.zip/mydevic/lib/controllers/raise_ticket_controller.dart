import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class RaiseTicketController extends GetxController{
  final TextEditingController assetType = TextEditingController();
  final TextEditingController assetSubType = TextEditingController();
  final TextEditingController issues = TextEditingController();
  final TextEditingController description = TextEditingController();

}