class AppImages {
  AppImages._();

  static String img1 = "assets/images/device.jpg";
  static String img2 = "assets/images/help_support.jpg";
  static String org = "assets/images/org.png";

  static String appIcon = "assets/images/app_icon.png";
  static String mainBottom = "assets/images/main_bottom.png";
  static String mainTop = "assets/images/main_top.png";
  static String loginBottom= "assets/images/login_bottom.png";

  static String signupTop = "assets/images/signup_top.png";


}
