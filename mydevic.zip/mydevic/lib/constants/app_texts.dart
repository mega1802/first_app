class AppTexts {
  AppTexts._();

  static const String primaryFontFamily = "Poppins";

  static const double influencerPrice = 199;
}
