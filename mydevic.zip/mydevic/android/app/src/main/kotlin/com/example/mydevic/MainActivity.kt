package com.example.mydevic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
